//
//  PlayOpenAL.h
//  speakDemo
//
//  Created by aolei on 2017/1/6.
//  Copyright © 2017年 xmw_mac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <OpenAL/OpenAL.h>
@interface PlayOpenAL : NSObject
- (void)playData:(NSData*)data;
@end
