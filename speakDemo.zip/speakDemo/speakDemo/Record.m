//
//  Record.m
//  speakDemo
//
//  Created by xmw_mac on 17/1/5.
//  Copyright © 2017年 xmw_mac. All rights reserved.
//

#import "Record.h"

@implementation Record
- (instancetype)init
{
    if (self = [super init])
    {
        _mDataFormat.mSampleRate = kDefaultSampleRate;
        _mDataFormat.mFormatID = kAudioFormatLinearPCM;
        _mDataFormat.mFormatFlags = kLinearPCMFormatFlagIsPacked|kLinearPCMFormatFlagIsSignedInteger;
        _mDataFormat.mFramesPerPacket = 1;
        _mDataFormat.mChannelsPerFrame = 2;
        _mDataFormat.mBitsPerChannel =  16;
        _mDataFormat.mBytesPerFrame = (_mDataFormat.mBitsPerChannel/8)*_mDataFormat.mChannelsPerFrame;
        _mDataFormat.mBytesPerPacket = _mDataFormat.mBytesPerFrame * _mDataFormat.mFramesPerPacket;
        
        AudioQueueNewInput(&_mDataFormat, AQueueInputCallback, (__bridge void*)(self), NULL, kCFRunLoopCommonModes, 0, &_recordQueue);
        // 给队列添加缓冲区
        AudioQueueBufferRef buffer[kNumberAudioQueueBuffers];
        OSStatus osState;
        for (int i=0;i<kNumberAudioQueueBuffers ;i++)
        {
            //请求音频队列对象来分配一个音频队列缓存。
            osState = AudioQueueAllocateBuffer(_recordQueue, MIN_SIZE_PER_FRAME, &buffer[i]);
            //给录音或者回放音频队列的缓存中添加一个缓存数据
            AudioQueueEnqueueBuffer(_recordQueue, buffer[i], 0, NULL);
        }

    }
    return self;
}

///回调函数
static void AQueueInputCallback(
                                void * __nullable               inUserData,
                                AudioQueueRef                   inAQ,
                                AudioQueueBufferRef             inBuffer,
                                const AudioTimeStamp *          inStartTime,
                                UInt32                          inNumberPacketDescriptions,
                                const AudioStreamPacketDescription * __nullable inPacketDescs)
{
    // 处理数据 inUserData 传入的是我们的控制器，因为要用到在它内部定义的队列属性
    Record * engine = (__bridge Record *) inUserData;
    unsigned int buf_length = inBuffer->mAudioDataByteSize;
    void * buf = inBuffer->mAudioData;
    if (buf_length == 0)
    {
        AudioQueueEnqueueBuffer(inAQ, inBuffer, 0, NULL);
        return;
    }
    NSData *data = [NSData dataWithBytes:buf length:buf_length];
    if (engine.sendBlock) engine.sendBlock(data);
    AudioQueueEnqueueBuffer(inAQ, inBuffer, 0, NULL);
}

- (void)startRecord
{
    AudioQueueStart(_recordQueue, NULL);
}
- (void)pauseRecord
{
    AudioQueuePause(_recordQueue);
}
@end
