//
//  Record.h
//  speakDemo
//
//  Created by xmw_mac on 17/1/5.
//  Copyright © 2017年 xmw_mac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AudioToolbox/AudioToolbox.h>
@interface Record : NSObject
///定义一个录音队列
@property (nonatomic, assign) AudioQueueRef recordQueue;
@property (nonatomic, assign) AudioStreamBasicDescription mDataFormat;
@property (nonatomic, copy) void (^sendBlock)(NSData *data);

#pragma mark -@public
- (void)startRecord;
- (void)pauseRecord;
@end
