//
//  SocketManager.h
//  speakDemo
//
//  Created by xmw_mac on 17/1/1.
//  Copyright © 2017年 xmw_mac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GCDAsyncUdpSocket.h"
@interface SocketManager : NSObject<GCDAsyncUdpSocketDelegate>
@property (nonatomic, strong) GCDAsyncUdpSocket *udpSocket;
+ (SocketManager*)shared;
- (void)bindToPort:(uint16_t)port;
@property (nonatomic, copy) void (^receiveBlock)(NSData *data);
@end
