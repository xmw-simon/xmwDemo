//
//  SocketManager.m
//  speakDemo
//
//  Created by xmw_mac on 17/1/1.
//  Copyright © 2017年 xmw_mac. All rights reserved.
//

#import "SocketManager.h"
static SocketManager * manager = nil;
@implementation SocketManager
+ (SocketManager*)shared
{
    @synchronized(self) {
        if (!manager) {
            manager = [SocketManager new];
        }
    }
    return manager;
}

- (instancetype)init
{
    if (self = [super init])
    {
        _udpSocket = [[GCDAsyncUdpSocket alloc] initWithDelegate:self delegateQueue:dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0) socketQueue:NULL];
        [_udpSocket setIPv6Enabled:NO];
        
        NSError *error = nil;
        BOOL flag = [_udpSocket enableBroadcast:YES error:&error];
        if (flag)
        {
            NSLog(@"----->成功开启广播");
        }
    }
    return self;
}

- (void)bindToPort:(uint16_t)port
{
    NSError *error = nil;
    [_udpSocket bindToPort:port error:&error];
    if (error)
    {
        NSLog(@"----->%@",error);
    }
    else
    {
        NSLog(@"----->成功监听端口");
       [_udpSocket beginReceiving:&error];
    }
}

#pragma mark -@protocol
#pragma mark -@protocol GCDAsyncUdpSocketDelegate
///发送数据结果
- (void)udpSocket:(GCDAsyncUdpSocket *)sock didSendDataWithTag:(long)tag
{
//    NSLog(@"----->数据发送成功 %zi",tag);
}

///接收数据
- (void)udpSocket:(GCDAsyncUdpSocket *)sock didReceiveData:(NSData *)data fromAddress:(NSData *)address withFilterContext:(id)filterContext
{
    if (self.receiveBlock)
    {
        self.receiveBlock(data);
    }
}

///数据发送失败
- (void)udpSocket:(GCDAsyncUdpSocket *)sock didNotSendDataWithTag:(long)tag dueToError:(NSError *)error
{
    NSLog(@"----->数据发送失败  %@",error);
}
@end
