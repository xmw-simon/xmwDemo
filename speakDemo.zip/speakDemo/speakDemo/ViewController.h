//
//  ViewController.h
//  speakDemo
//
//  Created by xmw_mac on 17/1/1.
//  Copyright © 2017年 xmw_mac. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSUInteger, CurrentType) {
    CurrentTypeNone,//空闲状态
    CurrentTypeListen,//听众
    CurrentTypeSpeak,//发言者
};

@interface ViewController : UIViewController


@end

