//
//  Player.h
//  speakDemo
//
//  Created by xmw_mac on 17/1/2.
//  Copyright © 2017年 xmw_mac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AudioToolbox/AudioToolbox.h>
typedef struct playState
{
    AudioStreamBasicDescription dataFormat;//输出音频的格式
    
    AudioQueueRef queue;//音频队列的对象AudioQueueRef
    AudioQueueBufferRef buffer[kNumberAudioQueueBuffers];//缓冲区
    BOOL bufferUsed[kNumberAudioQueueBuffers];
}PlayState;

@interface Player : NSObject
@property (nonatomic, assign) PlayState playState;
@property (nonatomic, strong) NSMutableData *tempData;

#pragma mark -@public
- (void)playData:(NSData*)data;

@end
