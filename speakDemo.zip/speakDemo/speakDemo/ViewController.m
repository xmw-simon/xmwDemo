//
//  ViewController.m
//  speakDemo
//
//  Created by xmw_mac on 17/1/1.
//  Copyright © 2017年 xmw_mac. All rights reserved.
//

#import "ViewController.h"
#import "SocketManager.h"
#import "STool.h"
#import "Record.h"
#import "Player.h"
#import "PlayOpenAL.h"
#import <AVFoundation/AVFoundation.h>
@interface ViewController ()
@property (nonatomic, strong) UILabel *stateView;
@property (nonatomic, strong) UIButton *speakView;
@property (nonatomic, strong) SocketManager *manager;
@property (nonatomic, assign) CurrentType type;
///定义一个播放实例
@property (nonatomic, strong) Player *play;
///定义一个录音实例
@property (nonatomic, strong) Record *record;
///广播地址
@property (nonatomic, copy) NSMutableString *broadcastAddress;
///OpenAL
@property (nonatomic, strong) PlayOpenAL *openAL;
@property (nonatomic, assign) BOOL isRecord;
@end

@implementation ViewController
- (void)viewDidLoad
{
    [super viewDidLoad];
    self.title = @"对讲";
    _isRecord = NO;
    //监听耳机事件
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(routeChanged:)
                                                 name:AVAudioSessionRouteChangeNotification
                                               object:nil];
    //配置AVAudioSession
    [[AVAudioSession sharedInstance] setActive:YES error:nil];
    [[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategoryPlayAndRecord error:nil];
    NSString *gateway = [STool getGatewayIPAddress];
    NSArray *ipList = [gateway componentsSeparatedByString:@"."];
    _broadcastAddress = [NSMutableString new];
    for (int i = 0; i < ipList.count; i++)
    {
        NSString *tempString = ipList[i];
        if (i != ipList.count - 1)
        {
            [_broadcastAddress appendString:tempString];
            [_broadcastAddress appendString:@"."];
        }
        else
        {
            [_broadcastAddress appendString:@"255"];
        }
    }
    
    [self _initConfig];
    //初始化播放
    _play = [[Player alloc] init];
    //初始化录音
    _record = [[Record alloc] init];
    _openAL = [[PlayOpenAL alloc] init];
    __weak typeof(self) _self = self;
    _record.sendBlock = ^(NSData *data){
        [_self _sendData:data];
    };
    [self.view addSubview:self.stateView];
    [self.view addSubview:self.speakView];
    [self _checkState];
}

#pragma mark -@init
- (UILabel*)stateView
{
    if (!_stateView)
    {
        _stateView = [[UILabel alloc] initWithFrame:CGRectMake((kScreenWidth - 200.f)/2, 120.f, 200.f, 36.f)];
        _stateView.textColor = [UIColor whiteColor];
        _stateView.backgroundColor = [UIColor blackColor];
        _stateView.layer.cornerRadius = 3.f;
        _stateView.textAlignment = NSTextAlignmentCenter;
        _stateView.layer.masksToBounds = YES;
    }
    return _stateView;
}


- (UIButton*)speakView
{
    if (!_speakView)
    {
        _speakView = [[UIButton alloc] initWithFrame:CGRectMake((kScreenWidth - 84.f)/2, kScreenHeight - 184.f, 84.f, 84.f)];
        _speakView.backgroundColor = [UIColor orangeColor];
        _speakView.titleLabel.font = [UIFont boldSystemFontOfSize:34.f];
        _speakView.layer.cornerRadius = 42.f;
        _speakView.layer.masksToBounds = YES;
        [_speakView addTarget:self action:@selector(startAction) forControlEvents:UIControlEventTouchDown];
        [_speakView addTarget:self action:@selector(cancleAction) forControlEvents: UIControlEventTouchUpInside];
        [_speakView setTitle:@"讲" forState:UIControlStateNormal];
    }
    return _speakView;
}

#pragma mark -@action
- (void)startAction
{
    if (!_isRecord)
    {
        [_record startRecord];
        _isRecord = YES;
    }
}


- (void)cancleAction
{
    if (_isRecord)
    {
        [_record pauseRecord];
        _isRecord = NO;
    }
    
}


#pragma mark -@private
- (void)_checkState
{
    _stateView.text = @"空闲中";
}


///初始化socket配置信息
- (void)_initConfig
{
    _manager = [SocketManager shared];
    //监听端口
    [_manager bindToPort:SPort];
    __weak typeof(self) _self = self;
    _manager.receiveBlock = ^(NSData *data){
        dispatch_async(dispatch_get_main_queue(), ^{
//            [_self.play playData:data];
            [_self.openAL playData:data];
        });
    };
}

- (UIColor*)_randColor
{
    return [UIColor colorWithRed:(arc4random()%255)/255.f green:(arc4random()%255)/255.f blue:(arc4random()%255)/255.f alpha:1.f];
}


- (void)_sendData:(NSData *)data
{
    [_manager.udpSocket sendData:data toHost:_broadcastAddress port:SPort withTimeout:30 tag:100];
}

- (void)routeChanged:(NSNotification*)notification
{
    NSLog(@"---->%@",notification.userInfo[AVAudioSessionRouteChangeReasonKey]);
    NSInteger routeChangeReason = [notification.userInfo[AVAudioSessionRouteChangeReasonKey] integerValue];
    switch (routeChangeReason) {
        case AVAudioSessionRouteChangeReasonNewDeviceAvailable:
            NSLog(@"----->耳机插入");
            break;
            
        case AVAudioSessionRouteChangeReasonOldDeviceUnavailable:
            NSLog(@"----->耳机拔出");
            break;
            
        case AVAudioSessionRouteChangeReasonCategoryChange:
            NSLog(@"----->常规状态");
            break;
    }
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

#pragma mark -@远程控制事件
-(void)remoteControlReceivedWithEvent:(UIEvent *)event
{
//    NSLog(@"%zi,%zi",event.type,event.subtype);
    if(event.type == UIEventTypeRemoteControl){
        switch (event.subtype) {
            case UIEventSubtypeRemoteControlPlay:
                NSLog(@"播放事件操作-->停止状态下，按耳机线控中间按钮一下");
                break;
            case UIEventSubtypeRemoteControlTogglePlayPause:
                if (!_isRecord)
                {
                    [self startAction];
                }
                else
                {
                    [self cancleAction];
                }
                NSLog(@"播放或暂停切换操作：播放或暂停状态下，按耳机线控中间按钮一下");
                break;
            case UIEventSubtypeRemoteControlNextTrack:
                NSLog(@"下一曲");
                break;
            case UIEventSubtypeRemoteControlPreviousTrack:
                NSLog(@"上一曲");
                break;
            case UIEventSubtypeRemoteControlBeginSeekingForward:
                NSLog(@"快进开始");
                break;
            case UIEventSubtypeRemoteControlEndSeekingForward:
                NSLog(@"快进结束");
                break;
            case UIEventSubtypeRemoteControlBeginSeekingBackward:
                NSLog(@"快退开始");
                break;
            case UIEventSubtypeRemoteControlEndSeekingBackward:
                NSLog(@"快退停止");
                break;
            default:
                break;
        }
    }
}





@end
