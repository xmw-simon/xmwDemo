//
//  AppDelegate.h
//  speakDemo
//
//  Created by xmw_mac on 17/1/1.
//  Copyright © 2017年 xmw_mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

