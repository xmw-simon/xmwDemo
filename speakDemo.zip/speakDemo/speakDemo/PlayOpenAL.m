//
//  PlayOpenAL.m
//  speakDemo
//
//  Created by aolei on 2017/1/6.
//  Copyright © 2017年 xmw_mac. All rights reserved.
//

#import "PlayOpenAL.h"

@implementation PlayOpenAL
{
    ALCdevice *mDevice;
    ALCcontext *mContext;
    unsigned int outSourceID;
}
- (instancetype)init
{
    if (self = [super init])
    {
        [self initOpenAL];
    }
    return self;
}

-(void)initOpenAL
{
    mDevice = alcOpenDevice(NULL);
    if (mDevice) {
        mContext = alcCreateContext(mDevice, NULL);
        alcMakeContextCurrent(mContext);
    }
    alGenSources(1, &outSourceID);
    alSourcei(outSourceID, AL_LOOPING, AL_FALSE);
    alSourcef(outSourceID, AL_SOURCE_TYPE, AL_STREAMING);
}

- (void)playData:(NSData*)data
{
    ALenum  error = AL_NO_ERROR;
    
    if (data.length == 0) return;
    NSCondition* ticketCondition= [[NSCondition alloc] init];
    [ticketCondition lock];
    [self updataQueueBuffer];
    
    ALuint bufferID = 0;
    alGenBuffers(1, &bufferID);
    if((error = alGetError()) != AL_NO_ERROR)
    {
        NSLog(@"error alGenBuffers: %x\n", error);
    }
    else
    {
        NSLog(@"suc alGenBuffers: %x\n", error);
        alBufferData(bufferID, AL_FORMAT_STEREO16, (const ALvoid*)[data bytes], (ALsizei)[data length], 8000);
        if((error = alGetError()) != AL_NO_ERROR)
        {
            NSLog(@"error sucalBufferData: %x\n", error);
        }
        else
        {
            NSLog(@"sucalBufferData: %x\n", error);
            alSourceQueueBuffers(outSourceID, 1, &bufferID);
            if((error = alGetError()) != AL_NO_ERROR)
            {
                NSLog(@"error alSourceQueueBuffers: %x\n", error);
            }
            else
            {
                NSLog(@"suc alSourceQueueBuffers: %x\n", error);
                ALint value;
                alGetSourcei(outSourceID,AL_SOURCE_STATE,&value);
                if (value != AL_PLAYING)
                {
                    alSourcePlay(outSourceID);
                }
                
                if((error = alGetError()) != AL_NO_ERROR)
                {
                    NSLog(@"error alSourcePlay: %x\n", error);
                    alDeleteBuffers(1, &bufferID);
                }
                else
                {
                    NSLog(@"suc alSourcePlay: %x\n", error);
                }
            }
        }
    }
    
    [ticketCondition unlock];
    ticketCondition = nil;
}

- (BOOL)updataQueueBuffer
{
    ALint stateVaue;
    int processed, queued;
    
    
    alGetSourcei(outSourceID, AL_SOURCE_STATE, &stateVaue);
    
    if (stateVaue == AL_STOPPED)
    {
        return NO;
    }
    
    
    alGetSourcei(outSourceID, AL_BUFFERS_PROCESSED, &processed);
    alGetSourcei(outSourceID, AL_BUFFERS_QUEUED, &queued);
    
    
    NSLog(@"Processed = %d\n", processed);
    NSLog(@"Queued = %d\n", queued);
    
    
    while(processed--)
    {
        ALuint buff;
        alSourceUnqueueBuffers(outSourceID, 1, &buff);
        alDeleteBuffers(1, &buff);
    }
    
    return YES;
}
@end
