//
//  Player.m
//  speakDemo
//
//  Created by xmw_mac on 17/1/2.
//  Copyright © 2017年 xmw_mac. All rights reserved.
//

#import "Player.h"
#import <AudioToolbox/AudioQueue.h>
#import <MediaPlayer/MediaPlayer.h>

@interface Player()
@end

@implementation Player

- (instancetype)init
{
    if (self = [super init])
    {
        _playState.dataFormat.mSampleRate = kDefaultSampleRate;
        _playState.dataFormat.mFormatID = kAudioFormatLinearPCM;
        _playState.dataFormat.mFormatFlags = kLinearPCMFormatFlagIsPacked|kLinearPCMFormatFlagIsSignedInteger;
        _playState.dataFormat.mFramesPerPacket = 1;
        _playState.dataFormat.mChannelsPerFrame = 2;
        _playState.dataFormat.mBitsPerChannel =  16;
        _playState.dataFormat.mBytesPerFrame = (_playState.dataFormat.mBitsPerChannel/8)*_playState.dataFormat.mChannelsPerFrame;
        _playState.dataFormat.mBytesPerPacket = _playState.dataFormat.mBytesPerFrame * _playState.dataFormat.mFramesPerPacket;
        _playState.dataFormat.mReserved = 0;
        AudioQueueNewOutput(&_playState.dataFormat, AQueueOutputCallback, (__bridge void*)(self), NULL, kCFRunLoopCommonModes, 0, &_playState.queue);
        // 设置音量
        AudioQueueSetParameter(_playState.queue, kAudioQueueParam_Volume, 1.0);
        
        // 初始化缓存区间
        for (int i = 0;i<kNumberAudioQueueBuffers ;i++)
        {
            _playState.bufferUsed[i] = false;
            //请求音频队列对象来分配一个音频队列缓存。
            AudioQueueAllocateBuffer(_playState.queue, MIN_SIZE_PER_FRAME, &_playState.buffer[i]);
//            AudioQueueEnqueueBuffer(_playState.queue, _playState.buffer[i], 0, NULL);
        }
       AudioQueueStart(_playState.queue, NULL);
    }
    return self;
}

static void AQueueOutputCallback(void* inUserData,AudioQueueRef inAQ,AudioQueueBufferRef buffer)
{
    Player * engine = (__bridge Player *) inUserData;
    [engine dealInfo:inAQ withBuffer:buffer];
    
}

- (void)dealInfo:(AudioQueueRef)inAQ withBuffer:(AudioQueueBufferRef)buffer
{
    for (int i = 0; i < kNumberAudioQueueBuffers; i++)
    {
        if (buffer == _playState.buffer[i])
        {
            NSLog(@"========>释放了!");
            _playState.bufferUsed[i] = false;
            break;
        }
    }
//    buffer->mAudioDataByteSize = 0;
//    
//    memcpy(buffer->mAudioData, [[NSData new] bytes], 0);
//    AudioQueueEnqueueBuffer(inAQ, buffer, 0, NULL);                                         
}

- (void)playData:(NSData *)data
{
    if (data.length ==0 ) return;
    AudioQueueBufferRef temp = NULL;
    for (int i = 0; i < kNumberAudioQueueBuffers; i++)
    {
        if (_playState.bufferUsed[i] == false)
        {
            _playState.bufferUsed[i] = true;
            temp = _playState.buffer[i];
            NSLog(@"----->执行了");
            break;
        }
    }
    if (!temp) return;
    temp->mAudioDataByteSize = (int)[data length];
    memcpy(temp->mAudioData, [data bytes], [data length]);
    AudioQueueEnqueueBuffer(_playState.queue,temp,0,nil);
}

@end
